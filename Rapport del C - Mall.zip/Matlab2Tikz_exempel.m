addpath() % To your matlab2tikz path on your computer
cleanfigure('minimumPointsDistance', 0.1) % Use this or
cleanfigure('targetResolution',PPI) 
matlab2tikz('myfigure.tex','width', '\fwidth', 'height', '\fheight');
